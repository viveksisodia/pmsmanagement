using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Web;
using System.Web.Services;
using System.Web.Script.Services;
using System.Web.UI;
using CommonClass;

public partial class pms_manager_dashboard : Page
{
    protected void Page_Load(object sender, EventArgs e) { }

    [WebMethod]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public static object GetEmployees()
    {
        HttpCookie tenant = HttpContext.Current.Request.Cookies["cadmin"];
        HttpCookie user = HttpContext.Current.Request.Cookies["user"];
        int regId, employeeId;
        if (tenant == null || user == null || !Int32.TryParse(tenant["id"], out regId) ||
            !Int32.TryParse(user["user_id"], out employeeId) || regId <= 0 || employeeId <= 0)
            throw new HttpException(401, "Login information is missing or invalid.");
        int isAdmin = IsAdmin(regId, employeeId) ? 1 : 0;
        SqlParameter[] prm = {
            new SqlParameter("@regid", regId),
            new SqlParameter("@isadmin", isAdmin),
            new SqlParameter("@uid", SqlDbType.Int) { Value = employeeId }
        };
        DataSet ds = new DataAccess().GetDataSet("pms_ManagerDashboardAllowedEmployees", prm);
        var result = new List<object>();
        var seen = new HashSet<int>();
        if (ds != null && ds.Tables.Count > 0) {
            DataTable table = ds.Tables[0];
            string idColumn = "id";
            string nameColumn = "DisplayName";
            if (table.Rows.Count > 0 && (!table.Columns.Contains(idColumn) || !table.Columns.Contains(nameColumn)))
                throw new InvalidOperationException("Employee procedure must return employee ID and name columns.");
            foreach (DataRow row in table.Rows) {
                int id;
                if (!Int32.TryParse(Convert.ToString(row[idColumn]), out id) || id <= 0 || !seen.Add(id)) continue;
                result.Add(new { id = id, name = Convert.ToString(row[nameColumn]) });
            }
        }
        return result;
    }
    [WebMethod]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public static object GetProjects(int employeeId, int projectId, string startDate, string endDate)
    {
        HttpCookie tenant = HttpContext.Current.Request.Cookies["cadmin"];
        HttpCookie user = HttpContext.Current.Request.Cookies["user"];
        int regId, uid;
        if (tenant == null || user == null || !Int32.TryParse(tenant["id"], out regId) ||
            !Int32.TryParse(user["user_id"], out uid) || regId <= 0 || uid <= 0)
            throw new HttpException(401, "Login information is missing or invalid.");
        if (employeeId < 0 || projectId < 0) throw new ArgumentException("Invalid filter.");
        // Resolve self and active reporting employees within this tenant.
        int admin = IsAdmin(regId, uid) ? 1 : 0;
        DataSet employees = new DataAccess().GetDataSet("pms_ManagerDashboardAllowedEmployees", new SqlParameter[] {
            new SqlParameter("@regid", regId), new SqlParameter("@isadmin", admin),
            new SqlParameter("@uid", SqlDbType.Int) { Value = uid }
        });
        var allowed = new HashSet<int>();
        if (employees != null && employees.Tables.Count > 0)
            foreach (DataRow row in employees.Tables[0].Rows) {
                int id; if (Int32.TryParse(Convert.ToString(row["id"]), out id) && id > 0) allowed.Add(id);
            }
        var ids = new List<string>();
        foreach (int id in allowed) ids.Add(id.ToString(CultureInfo.InvariantCulture));
        DateTime? from = ParseFilterDate(startDate), to = ParseFilterDate(endDate);
        if (from.HasValue && to.HasValue && from > to) throw new ArgumentException("Invalid date range.");
        DataSet ds = new DataAccess().GetDataSet("pms_ManagerDashboardProjects", new SqlParameter[] {
            new SqlParameter("@regid", regId), new SqlParameter("@isadmin", admin),
            new SqlParameter("@AllowedEmployeeIds", SqlDbType.NVarChar, -1) { Value = String.Join(",", ids.ToArray()) },
            new SqlParameter("@employeeId", employeeId), new SqlParameter("@projectId", projectId),
            new SqlParameter("@startDate", SqlDbType.Date) { Value = from.HasValue ? (object)from.Value : DBNull.Value },
            new SqlParameter("@endDate", SqlDbType.Date) { Value = to.HasValue ? (object)to.Value : DBNull.Value }
        });
        if (ds == null || ds.Tables.Count < 8) throw new InvalidOperationException("Install the supplied dashboard procedure first.");
        return new { projects = Rows(ds.Tables[0]), masters = Rows(ds.Tables[1]), milestones = Rows(ds.Tables[2]), projectOptions = Rows(ds.Tables[3]), itemGroups = Rows(ds.Tables[4]), taskProjects = Rows(ds.Tables[5]), issueProjects = Rows(ds.Tables[6]), tags = Rows(ds.Tables[7]) };
    }
    private static DateTime? ParseFilterDate(string value)
    {
        if (String.IsNullOrWhiteSpace(value)) return null;
        DateTime date;
        if (!DateTime.TryParseExact(value, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out date))
            throw new ArgumentException("Date must use yyyy-MM-dd.");
        return date.Date;
    }
    private static List<Dictionary<string, object>> Rows(DataTable table)
    {
        var rows = new List<Dictionary<string, object>>();
        foreach (DataRow row in table.Rows) {
            var item = new Dictionary<string, object>();
            foreach (DataColumn col in table.Columns)
                item[col.ColumnName] = row[col] == DBNull.Value ? null : row[col] is DateTime ? ((DateTime)row[col]).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) : row[col];
            rows.Add(item);
        }
        return rows;
    }
    private static bool IsAdmin(int regId, int employeeId)
    {
        string sql = "SELECT TOP 1 mp.id FROM dbo.Manage_Profile mp " +
            "INNER JOIN dbo.tbl_employee e ON mp.id=TRY_CONVERT(int,e.roleid) " +
            "WHERE e.id=" + employeeId.ToString(CultureInfo.InvariantCulture) +
            " AND e.regid=" + regId.ToString(CultureInfo.InvariantCulture) +
            " AND mp.status=1 AND mp.archive=0";
        DataSet ds = new DataAccess().GetDataSetInline(sql);
        return ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0 &&
            Convert.ToInt32(ds.Tables[0].Rows[0]["id"], CultureInfo.InvariantCulture) == 1;
    }
}
