CREATE OR ALTER PROCEDURE dbo.pms_ManagerDashboardProjects
 @regid int, @isadmin int, @AllowedEmployeeIds nvarchar(max),
 @employeeId int = 0, @projectId int = 0, @startDate date = NULL, @endDate date = NULL
AS
BEGIN
 SET NOCOUNT ON;
 -- Allowed IDs come from pms_ManagerDashboardAllowedEmployees on the server, never from the browser.
 SELECT TRY_CONVERT(int, n.value('.', 'nvarchar(30)')) AS id INTO #Allowed
 FROM (SELECT CONVERT(xml, '<i>'+REPLACE(@AllowedEmployeeIds,',','</i><i>')+'</i>') AS ids) a
 CROSS APPLY a.ids.nodes('/i') b(n);
 CREATE UNIQUE CLUSTERED INDEX IX_Allowed ON #Allowed(id);
 IF @employeeId > 0 AND NOT EXISTS(SELECT 1 FROM #Allowed WHERE id=@employeeId)
 BEGIN; THROW 50001, 'Employee is outside your permitted hierarchy.', 1; END;
 CREATE TABLE #SelectedEmployees(id int NOT NULL PRIMARY KEY);
 IF @employeeId>0
 BEGIN
  INSERT INTO #SelectedEmployees VALUES(@employeeId);
  WHILE 1=1
  BEGIN
   INSERT INTO #SelectedEmployees(id)
   SELECT DISTINCT e.id FROM dbo.tbl_employee e
   JOIN #SelectedEmployees manager ON manager.id=TRY_CONVERT(int,e.councelor_id)
   WHERE e.regid=@regid AND e.status=1 AND e.archive=0
   AND NOT EXISTS(SELECT 1 FROM #SelectedEmployees seen WHERE seen.id=e.id)
   AND (@isadmin=1 OR EXISTS(SELECT 1 FROM #Allowed a WHERE a.id=e.id));
   IF @@ROWCOUNT=0 BREAK;
  END;
 END;
 SELECT p.*, REPLACE(REPLACE(REPLACE(ISNULL(CONVERT(nvarchar(max),p.team),''),' ',''),';',','),'|',',') AS DashboardTeamIds INTO #AuthorizedProjects
 FROM dbo.Pms_tbl_AddProject p
 WHERE p.regid=@regid AND p.status=1 AND p.archive=0
 AND (@isadmin=1 OR EXISTS(SELECT 1 FROM #Allowed a WHERE
   TRY_CONVERT(int,p.owner)=a.id OR
   CHARINDEX(','+CONVERT(varchar(20),a.id)+',',','+REPLACE(REPLACE(REPLACE(ISNULL(CONVERT(nvarchar(max),p.team),''),' ',''),';',','),'|',',')+',')>0))
 AND (@employeeId=0 OR EXISTS(SELECT 1 FROM #SelectedEmployees selected WHERE TRY_CONVERT(int,p.owner)=selected.id OR
   CHARINDEX(','+CONVERT(varchar(20),selected.id)+',',','+REPLACE(REPLACE(REPLACE(ISNULL(CONVERT(nvarchar(max),p.team),''),' ',''),';',','),'|',',')+',')>0))
;
 CREATE UNIQUE CLUSTERED INDEX IX_AuthorizedProjects ON #AuthorizedProjects(id);
 SELECT p.* INTO #Scope FROM #AuthorizedProjects p WHERE 1=1
 AND (@endDate IS NULL OR COALESCE(TRY_CONVERT(date,NULLIF(LTRIM(RTRIM(CONVERT(nvarchar(50),p.StartDate,126))),'')),TRY_CONVERT(date,p.cdate))<=@endDate)
 AND (@startDate IS NULL OR COALESCE(TRY_CONVERT(date,NULLIF(LTRIM(RTRIM(CONVERT(nvarchar(50),p.TargetDate,126))),'')),TRY_CONVERT(date,p.cdate))>=@startDate);
 SELECT * INTO #Projects FROM #Scope WHERE @projectId=0 OR id=@projectId;
 CREATE UNIQUE CLUSTERED INDEX IX_Projects ON #Projects(id);
 -- Each level uses its own dates and employee membership, within authorized projects.
 CREATE TABLE #Items(Kind nvarchar(20) COLLATE DATABASE_DEFAULT,ItemId int,ProjectId int,StatusId int,PriorityId int,SituationId int,TagIds nvarchar(max) COLLATE DATABASE_DEFAULT);
 DECLARE @kind nvarchar(20),@table sysname,@finish sysname,@priority nvarchar(100),@situation nvarchar(100),@sql nvarchar(max);
 DECLARE levels CURSOR LOCAL FAST_FORWARD FOR
 SELECT 'Milestone','Pms_tbl_AddMilestone','EndDate' UNION ALL
 SELECT 'Task','Pms_tbl_AddTask','Targetdate' UNION ALL
 SELECT 'Subtask','Pms_tbl_AddSubtask','Targetdate';
 OPEN levels; FETCH NEXT FROM levels INTO @kind,@table,@finish;
 WHILE @@FETCH_STATUS=0
 BEGIN
  SET @priority=CASE WHEN COL_LENGTH('dbo.'+@table,'Priority') IS NOT NULL THEN 'TRY_CONVERT(int,i.Priority)'
    WHEN COL_LENGTH('dbo.'+@table,'P_Priority') IS NOT NULL THEN 'TRY_CONVERT(int,i.P_Priority)' ELSE 'NULL' END;
  SET @situation=CASE WHEN COL_LENGTH('dbo.'+@table,'CriticalLabelId') IS NOT NULL THEN 'TRY_CONVERT(int,i.CriticalLabelId)' ELSE 'NULL' END;
  SET @sql=N'INSERT INTO #Items SELECT @kind,i.id,i.ProjectId,TRY_CONVERT(int,i.P_Status),'+@priority+','+@situation+',CONVERT(nvarchar(max),i.tagids)
   FROM dbo.'+QUOTENAME(@table)+' i JOIN #AuthorizedProjects p ON p.id=i.ProjectId AND p.regid=i.regid
   WHERE i.regid=@regid AND i.status=1 AND i.archive=0 AND (@projectId=0 OR i.ProjectId=@projectId)
   AND (@isadmin=1 OR EXISTS(SELECT 1 FROM #Allowed a WHERE TRY_CONVERT(int,i.owner)=a.id OR
     CHARINDEX('',''+CONVERT(varchar(20),a.id)+'','', '',''+REPLACE(REPLACE(REPLACE(ISNULL(CONVERT(nvarchar(max),i.team),''''),'' '',''''),'';'','',''),''|'','','')+'','')>0 OR (@kind=''Subtask'' AND EXISTS(SELECT 1 FROM dbo.Pms_tbl_assigntasks assignment
 WHERE assignment.regid=i.regid AND assignment.projectid=i.ProjectId
 AND assignment.subtaskid=i.id AND assignment.tasktype=''subtask''
 AND assignment.status=1 AND assignment.archive=0 AND assignment.uid=a.id))))
   AND (@employeeId=0 OR EXISTS(SELECT 1 FROM #SelectedEmployees selected WHERE TRY_CONVERT(int,i.owner)=selected.id OR
     CHARINDEX('',''+CONVERT(varchar(20),selected.id)+'','', '',''+REPLACE(REPLACE(REPLACE(ISNULL(CONVERT(nvarchar(max),i.team),''''),'' '',''''),'';'','',''),''|'','','')+'','')>0 OR (@kind=''Subtask'' AND EXISTS(SELECT 1 FROM dbo.Pms_tbl_assigntasks assignment
 WHERE assignment.regid=i.regid AND assignment.projectid=i.ProjectId
 AND assignment.subtaskid=i.id AND assignment.tasktype=''subtask''
 AND assignment.status=1 AND assignment.archive=0 AND assignment.uid=selected.id))))
   AND (@endDate IS NULL OR COALESCE(TRY_CONVERT(date,NULLIF(LTRIM(RTRIM(CONVERT(nvarchar(50),i.StartDate,126))),'''')),TRY_CONVERT(date,i.cdate))<=@endDate)
   AND (@startDate IS NULL OR COALESCE(TRY_CONVERT(date,NULLIF(LTRIM(RTRIM(CONVERT(nvarchar(50),i.'+QUOTENAME(@finish)+',126))),'''')),TRY_CONVERT(date,i.cdate))>=@startDate);';
  EXEC sys.sp_executesql @sql,N'@kind nvarchar(20),@regid int,@isadmin int,@employeeId int,@projectId int,@startDate date,@endDate date',
   @kind,@regid,@isadmin,@employeeId,@projectId,@startDate,@endDate;
  FETCH NEXT FROM levels INTO @kind,@table,@finish;
 END
 CLOSE levels; DEALLOCATE levels;
 CREATE INDEX IX_Items_KindItem ON #Items(Kind,ItemId);
 CREATE INDEX IX_Items_ProjectKind ON #Items(ProjectId,Kind) INCLUDE(StatusId,PriorityId);
 SELECT p.id,p.ProjectName,TRY_CONVERT(int,p.ProjectStatus) AS StatusId,
 TRY_CONVERT(int,p.Priority) AS PriorityId,TRY_CONVERT(int,p.CriticalLabelId) AS SituationId,
 CASE WHEN TRY_CONVERT(decimal(9,2),p.iscompletepercentage)<0 THEN 0
 WHEN TRY_CONVERT(decimal(9,2),p.iscompletepercentage)>100 THEN 100
 ELSE ISNULL(TRY_CONVERT(decimal(9,2),p.iscompletepercentage),0) END AS Completion,
 COALESCE(TRY_CONVERT(date,NULLIF(LTRIM(RTRIM(CONVERT(nvarchar(50),p.TargetDate,126))),'')),TRY_CONVERT(date,p.cdate)) AS Deadline,
 ISNULL(e.DisplayName,'') AS OwnerName,
 ISNULL(STUFF((SELECT ', '+ISNULL(te.DisplayName,'') FROM dbo.tbl_employee te
 WHERE te.regid=@regid AND CHARINDEX(','+CONVERT(varchar(20),te.id)+',',','+p.DashboardTeamIds+',')>0
 ORDER BY te.DisplayName FOR XML PATH(''),TYPE).value('.','nvarchar(max)'),1,2,''),'') AS TeamNames
 FROM #Projects p LEFT JOIN dbo.tbl_employee e ON e.regid=@regid AND e.id=TRY_CONVERT(int,p.owner)
 ORDER BY p.ProjectName,p.id;
 SELECT 'Status' AS Kind,id,ProjectStatus AS Name,PrintColor AS Color FROM dbo.Pms_tbl_Projectstatus WHERE regid=@regid AND status=1 AND archive=0
 UNION ALL SELECT 'Priority',id,name,PrintColor FROM dbo.Pms_tbl_Priority WHERE regid=@regid AND status=1 AND archive=0
 UNION ALL SELECT 'Situation',id,CriticalLabel,ColorCode FROM dbo.Pms_tbl_CriticalLabel WHERE regid=@regid AND status=1 AND archive=0;
 SELECT m.ProjectId,m.id,m.Milestone AS Name,
 COUNT(t.id) AS TotalTasks,SUM(CASE WHEN ps.iscomplete=1 THEN 1 ELSE 0 END) AS CompletedTasks,
 CASE WHEN COUNT(t.id)=0 THEN CASE WHEN ms.iscomplete=1 THEN 100.0 ELSE 0.0 END
 ELSE 100.0*SUM(CASE WHEN ps.iscomplete=1 THEN 1 ELSE 0 END)/COUNT(t.id) END AS Completion
 FROM dbo.Pms_tbl_AddMilestone m JOIN #Projects p ON p.id=m.ProjectId AND p.regid=m.regid
 LEFT JOIN dbo.Pms_tbl_Projectstatus ms ON ms.id=TRY_CONVERT(int,m.P_Status) AND ms.regid=m.regid
 -- Count active child tasks within employee access; retain date-independent totals.
 LEFT JOIN dbo.Pms_tbl_AddTask t ON t.Milestoneid=m.id AND t.ProjectId=m.ProjectId AND t.regid=m.regid AND t.status=1 AND t.archive=0
 AND (@isadmin=1 OR EXISTS(SELECT 1 FROM #Allowed a WHERE
 TRY_CONVERT(int,t.owner)=a.id OR
 CHARINDEX(','+CONVERT(varchar(20),a.id)+',',','+REPLACE(REPLACE(REPLACE(ISNULL(CONVERT(nvarchar(max),t.team),''),' ',''),';',','),'|',',')+',')>0))
 AND (@employeeId=0 OR EXISTS(SELECT 1 FROM #SelectedEmployees selected WHERE TRY_CONVERT(int,t.owner)=selected.id OR
 CHARINDEX(','+CONVERT(varchar(20),selected.id)+',',','+REPLACE(REPLACE(REPLACE(ISNULL(CONVERT(nvarchar(max),t.team),''),' ',''),';',','),'|',',')+',')>0))
 LEFT JOIN dbo.Pms_tbl_Projectstatus ps ON ps.id=TRY_CONVERT(int,t.P_Status) AND ps.regid=t.regid
 WHERE m.status=1 AND m.archive=0 AND EXISTS(SELECT 1 FROM #Items fi WHERE fi.Kind='Milestone' AND fi.ItemId=m.id)
 GROUP BY m.ProjectId,m.id,m.Milestone,ms.iscomplete ORDER BY m.ProjectId,m.id;
 SELECT id,ProjectName FROM #AuthorizedProjects ORDER BY ProjectName,id;
 SELECT Kind,StatusId,PriorityId,SituationId,COUNT(*) AS Count FROM #Items GROUP BY Kind,StatusId,PriorityId,SituationId;
 SELECT i.ProjectId,p.ProjectName,i.StatusId,i.PriorityId,COUNT(*) AS Count FROM #Items i
 JOIN #AuthorizedProjects p ON p.id=i.ProjectId WHERE i.Kind='Task'
 GROUP BY i.ProjectId,p.ProjectName,i.StatusId,i.PriorityId ORDER BY p.ProjectName,i.ProjectId;

 -- Project-level issues, consistent with the existing Projects module.
 SELECT p.id AS ProjectId,COUNT(i.id) AS Total,
 SUM(CASE WHEN ps.iscomplete=1 THEN 1 ELSE 0 END) AS Completed
 FROM #Projects p LEFT JOIN dbo.Pms_tbl_AddIssues i ON i.ProjectId=p.id AND i.regid=p.regid
 AND i.Issueon='Project' AND i.status=1 AND i.archive=0
 LEFT JOIN dbo.Pms_tbl_Projectstatus ps ON ps.id=TRY_CONVERT(int,i.IssueStatus) AND ps.regid=i.regid AND ps.status=1 AND ps.archive=0
 GROUP BY p.id;

 -- Count each matching project/milestone/task/subtask once per tag.
 ;WITH TaggedItems AS (
  SELECT CONVERT(nvarchar(max),tagids) COLLATE DATABASE_DEFAULT AS TagIds FROM #Projects
  UNION ALL SELECT TagIds COLLATE DATABASE_DEFAULT FROM #Items
 )
 SELECT REPLACE(REPLACE(REPLACE(ISNULL(TagIds,''),' ',''),';',','),'|',',') AS TagIds
 INTO #NormalizedTags FROM TaggedItems;
 SELECT tag.id,tag.Tags AS Name,ISNULL(NULLIF(tag.TagsColor,''),'#607d8b') AS Color,
 COUNT(*) AS Count
 FROM dbo.Pms_tbl_Addtags tag JOIN #NormalizedTags item ON
 CHARINDEX(','+CONVERT(varchar(20),tag.id)+',',
 ','+item.TagIds COLLATE DATABASE_DEFAULT+',')>0
 WHERE tag.regid=@regid AND tag.status=1 AND tag.archive=0
 GROUP BY tag.id,tag.Tags,tag.TagsColor
 ORDER BY Count DESC,tag.Tags;

END
