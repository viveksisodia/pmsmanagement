CREATE OR ALTER PROCEDURE dbo.pms_ManagerDashboardAllowedEmployees
 @regid int, @isadmin int, @uid int
AS
BEGIN
 SET NOCOUNT ON;
 -- Determine the role from database state on every request.
 SET @isadmin=CASE WHEN EXISTS(
 SELECT 1 FROM dbo.tbl_employee e JOIN dbo.Manage_Profile mp ON mp.id=TRY_CONVERT(int,e.roleid)
 WHERE e.regid=@regid AND e.id=@uid AND mp.id=1 AND mp.status=1 AND mp.archive=0
 ) THEN 1 ELSE 0 END;
 IF @isadmin=1
 BEGIN
  SELECT id,DisplayName FROM dbo.tbl_employee
  WHERE regid=@regid AND status=1 AND archive=0 ORDER BY DisplayName,id;
  SELECT @isadmin AS IsAdmin;
  RETURN;
 END;
 CREATE TABLE #Employees(id int NOT NULL PRIMARY KEY);
 INSERT INTO #Employees(id)
 SELECT id FROM dbo.tbl_employee WHERE id=@uid AND regid=@regid AND status=1 AND archive=0;
 -- Iteration handles all reporting levels and terminates even for cyclic data.
 WHILE 1=1
 BEGIN
  INSERT INTO #Employees(id)
  SELECT DISTINCT e.id FROM dbo.tbl_employee e
  JOIN #Employees manager ON manager.id=TRY_CONVERT(int,e.councelor_id)
  WHERE e.regid=@regid AND e.status=1 AND e.archive=0
  AND NOT EXISTS(SELECT 1 FROM #Employees seen WHERE seen.id=e.id);
  IF @@ROWCOUNT=0 BREAK;
 END;
 SELECT e.id,e.DisplayName FROM dbo.tbl_employee e
 JOIN #Employees a ON a.id=e.id WHERE e.regid=@regid ORDER BY e.DisplayName,e.id;
 SELECT @isadmin AS IsAdmin;
END;
