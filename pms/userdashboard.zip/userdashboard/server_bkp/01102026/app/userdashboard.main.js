(function () {
    'use strict';

    angular.module('pmsUserDashboardApp', ['pmsUserDashboard.services'])
        .controller('UserDashboardController', ['$scope', 'UserDashboardService', function ($scope, UserDashboardService) {
            var vm = this;
            vm.loading = true;
            vm.hasLoaded = false;
            vm.error = '';
            var requestSequence = 0;
            var hoursRequestSequence = 0;
            vm.hoursLoading = false;
            vm.hoursLoaded = false;
            vm.hoursError = '';
            vm.hoursPeriod = 'week';
            vm.hoursPeriods = [{ value: 'week', label: 'This Week' }, { value: 'today', label: 'Today' }];
            vm.rangeMenuOpen = false;
            vm.customMode = false;
            vm.rangeError = '';
            vm.presets = ['All', 'Today', 'This Week', 'This Month', 'This Quarter', 'This Year', 'Yesterday', 'Previous Week', 'Previous Month', 'Previous Quarter', 'Previous Year', 'Custom Range'];
            vm.selectedPreset = 'Today';
            vm.data = {};

            function dateOnly(date) {
                return new Date(date.getFullYear(), date.getMonth(), date.getDate());
            }
            function addDays(date, count) {
                var result = dateOnly(date);
                result.setDate(result.getDate() + count);
                return result;
            }
            function startOfWeek(date) {
                return addDays(date, -date.getDay());
            }
            function endOfMonth(date) {
                return new Date(date.getFullYear(), date.getMonth() + 1, 0);
            }
            function startOfQuarter(date) {
                return new Date(date.getFullYear(), Math.floor(date.getMonth() / 3) * 3, 1);
            }
            function endOfQuarter(date) {
                return new Date(date.getFullYear(), Math.floor(date.getMonth() / 3) * 3 + 3, 0);
            }
            function toApiDate(date) {
                var d = dateOnly(date);
                return ('0' + d.getDate()).slice(-2) + '/' + ('0' + (d.getMonth() + 1)).slice(-2) + '/' + d.getFullYear();
            }
            function setRange(start, end, label, closeMenu) {
                vm.rangeFrom = dateOnly(start);
                vm.rangeTo = dateOnly(end);
                vm.customFromDate = new Date(vm.rangeFrom.getTime());
                vm.customToDate = new Date(vm.rangeTo.getTime());
                vm.rangeDisplay = toApiDate(vm.rangeFrom) + ' - ' + toApiDate(vm.rangeTo);
                vm.selectedPreset = label || '';
                vm.customMode = label === 'Custom Range';
                vm.rangeError = '';
                if (closeMenu) vm.rangeMenuOpen = false;
                vm.load(toApiDate(vm.rangeFrom), toApiDate(vm.rangeTo));
            }

            vm.load = function (fromDate, toDate) {
                var thisRequest = ++requestSequence;
                vm.loading = true;
                vm.error = '';
                UserDashboardService.getDashboard(fromDate, toDate).then(function (data) {
                    if (thisRequest !== requestSequence) return;
                    var currentHours = vm.data && vm.data.hours;
                    vm.data = data;
                    if (vm.hoursLoaded && currentHours) vm.data.hours = currentHours;
                    vm.hasLoaded = true;
                }).catch(function () {
                    if (thisRequest === requestSequence) vm.error = 'Unable to load dashboard data. Please try again.';
                }).finally(function () {
                    if (thisRequest !== requestSequence) return;
                    vm.loading = false;
                    $scope.$evalAsync();
                });
            };

            vm.loadTaskHours = function (period) {
                var today = dateOnly(new Date());
                var rangeStart = today;
                var rangeEnd = today;
                if (period === 'week') {
                    rangeStart = startOfWeek(today);
                    rangeEnd = addDays(rangeStart, 6);
                }
                var thisRequest = ++hoursRequestSequence;
                vm.hoursPeriod = period;
                vm.hoursLoading = true;
                vm.hoursError = '';
                UserDashboardService.getTaskHours(toApiDate(rangeStart), toApiDate(rangeEnd)).then(function (hours) {
                    if (thisRequest !== hoursRequestSequence) return;
                    vm.data = vm.data || {};
                    vm.data.hours = hours;
                    vm.hoursLoaded = true;
                }).catch(function () {
                    if (thisRequest === hoursRequestSequence) vm.hoursError = 'Unable to update Task Hours.';
                }).finally(function () {
                    if (thisRequest !== hoursRequestSequence) return;
                    vm.hoursLoading = false;
                    $scope.$evalAsync();
                });
            };

            vm.toggleRangeMenu = function () {
                vm.rangeMenuOpen = !vm.rangeMenuOpen;
                vm.customMode = vm.rangeMenuOpen && vm.selectedPreset === 'Custom Range';
                vm.rangeError = '';
            };

            vm.openCalendar = function (event) {
                var input = event && event.currentTarget;
                if (!input) return;
                try {
                    if (typeof input.showPicker === 'function') {
                        input.showPicker();
                        return;
                    }
                } catch (ignore) { }
                input.focus();
            };

            vm.selectPreset = function (preset) {
                if (preset === 'Custom Range') {
                    vm.selectedPreset = preset;
                    vm.customMode = true;
                    vm.rangeError = '';
                    return;
                }
                var today = dateOnly(new Date());
                var start = today;
                var end = today;
                var weekStart = startOfWeek(today);
                if (preset === 'All') start = new Date(2020, 0, 1);
                else if (preset === 'This Week') { start = weekStart; end = addDays(weekStart, 6); }
                else if (preset === 'This Month') { start = new Date(today.getFullYear(), today.getMonth(), 1); end = endOfMonth(today); }
                else if (preset === 'This Quarter') { start = startOfQuarter(today); end = endOfQuarter(today); }
                else if (preset === 'This Year') { start = new Date(today.getFullYear(), 0, 1); end = new Date(today.getFullYear(), 11, 31); }
                else if (preset === 'Yesterday') { start = addDays(today, -1); end = start; }
                else if (preset === 'Previous Week') { start = addDays(weekStart, -7); end = addDays(weekStart, -1); }
                else if (preset === 'Previous Month') { start = new Date(today.getFullYear(), today.getMonth() - 1, 1); end = new Date(today.getFullYear(), today.getMonth(), 0); }
                else if (preset === 'Previous Quarter') { start = new Date(startOfQuarter(today).getFullYear(), startOfQuarter(today).getMonth() - 3, 1); end = addDays(startOfQuarter(today), -1); }
                else if (preset === 'Previous Year') { start = new Date(today.getFullYear() - 1, 0, 1); end = new Date(today.getFullYear() - 1, 11, 31); }
                setRange(start, end, preset, true);
            };

            vm.applyCustomRange = function () {
                if (!(vm.customFromDate instanceof Date) || isNaN(vm.customFromDate.getTime()) || !(vm.customToDate instanceof Date) || isNaN(vm.customToDate.getTime())) {
                    vm.rangeError = 'Select both From Date and To Date.';
                    return;
                }
                if (dateOnly(vm.customToDate) < dateOnly(vm.customFromDate)) {
                    vm.rangeError = 'To Date must be on or after From Date.';
                    return;
                }
                setRange(vm.customFromDate, vm.customToDate, 'Custom Range', true);
            };

            vm.loadTaskHours(vm.hoursPeriod);
            var today = dateOnly(new Date());
            setRange(today, today, 'Today', false);
        }]);
}());
