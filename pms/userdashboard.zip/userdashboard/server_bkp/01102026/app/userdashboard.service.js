(function () {
    'use strict';

    angular.module('pmsUserDashboard.services', [])
        .factory('UserDashboardService', ['$http', function ($http) {
            var apiUrl = 'default.aspx/GetUserDashboardData';

            return {
                getDashboard: function (fromDate, toDate) {
                    return $http.post(apiUrl, { fromDate: fromDate, toDate: toDate }).then(function (response) {
                        var data = response.data && response.data.d ? response.data.d : response.data;
                        if (typeof data === 'string') data = JSON.parse(data);
                        return data;
                    });
                },
                getTaskHours: function (fromDate, toDate) {
                    return $http.post('default.aspx/GetTaskHoursData', { fromDate: fromDate, toDate: toDate }).then(function (response) {
                        var data = response.data && response.data.d ? response.data.d : response.data;
                        if (typeof data === 'string') data = JSON.parse(data);
                        return data;
                    });
                }
            };
        }]);
}());
