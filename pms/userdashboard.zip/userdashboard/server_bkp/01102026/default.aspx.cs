using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.Script.Services;
using System.Web.UI;
using CommonClass;

public partial class userdashboard : Page
{
    [WebMethod]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public static object GetUserDashboardData(string fromDate, string toDate)
    {
        HttpCookie tenantCookie = HttpContext.Current.Request.Cookies["cadmin"];
        HttpCookie userCookie = HttpContext.Current.Request.Cookies["user"];
        if (tenantCookie == null || userCookie == null || String.IsNullOrWhiteSpace(tenantCookie["id"]) || String.IsNullOrWhiteSpace(userCookie["user_id"]))
            throw new HttpException(401, "Login information is missing.");

        DateTime rangeStart = ParseDashboardDate(fromDate, DateTime.Today.AddDays(-(((int)DateTime.Today.DayOfWeek + 6) % 7)));
        DateTime rangeEnd = ParseDashboardDate(toDate, rangeStart.AddDays(6));
        if (rangeEnd < rangeStart)
        {
            DateTime swap = rangeStart;
            rangeStart = rangeEnd;
            rangeEnd = swap;
        }
        rangeStart = rangeStart.Date;
        rangeEnd = rangeEnd.Date;

        string regId = tenantCookie["id"];
        string userId = userCookie["user_id"];
        SqlParameter[] parameters =
        {
            new SqlParameter("@RegId", regId),
            new SqlParameter("@UserId", userId),
            new SqlParameter("@FromDate", SqlDbType.Date) { Value = rangeStart },
            new SqlParameter("@ToDate", SqlDbType.Date) { Value = rangeEnd }
        };

        DataAccess dataAccess = new DataAccess();
        DataSet data = dataAccess.GetDataSet("dbo.usp_Pms_UserDashboard_GetAssignedSubtasks", parameters);
        DataTable rows = data != null && data.Tables.Count > 0 ? data.Tables[0] : new DataTable();
        return BuildDashboard(rows, rangeStart, rangeEnd, regId);
    }

    [WebMethod]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public static object GetTaskHoursData(string fromDate, string toDate)
    {
        HttpCookie tenantCookie = HttpContext.Current.Request.Cookies["cadmin"];
        HttpCookie userCookie = HttpContext.Current.Request.Cookies["user"];
        if (tenantCookie == null || userCookie == null || String.IsNullOrWhiteSpace(tenantCookie["id"]) || String.IsNullOrWhiteSpace(userCookie["user_id"]))
            throw new HttpException(401, "Login information is missing.");

        DateTime rangeStart = ParseDashboardDate(fromDate, DateTime.Today);
        DateTime rangeEnd = ParseDashboardDate(toDate, rangeStart);
        if (rangeEnd < rangeStart)
        {
            DateTime swap = rangeStart;
            rangeStart = rangeEnd;
            rangeEnd = swap;
        }
        rangeStart = rangeStart.Date;
        rangeEnd = rangeEnd.Date;

        SqlParameter[] parameters =
        {
            new SqlParameter("@RegId", tenantCookie["id"]),
            new SqlParameter("@UserId", userCookie["user_id"]),
            new SqlParameter("@FromDate", SqlDbType.Date) { Value = rangeStart },
            new SqlParameter("@ToDate", SqlDbType.Date) { Value = rangeEnd }
        };

        DataAccess dataAccess = new DataAccess();
        DataSet data = dataAccess.GetDataSet("dbo.usp_Pms_UserDashboard_GetAssignedSubtasks", parameters);
        DataTable rows = data != null && data.Tables.Count > 0 ? data.Tables[0] : new DataTable();
        return new { days = BuildHours(rows.Rows.Cast<DataRow>().ToList(), rangeStart, rangeEnd) };
    }

    private static DateTime ParseDashboardDate(string value, DateTime fallback)
    {
        DateTime result;
        return DateTime.TryParseExact(value, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out result) ? result.Date : fallback.Date;
    }

    private static object BuildDashboard(DataTable rows, DateTime rangeStart, DateTime rangeEnd, string regId)
    {
        List<DataRow> records = rows.Rows.Cast<DataRow>().ToList();
        int total = records.Count;
        List<GroupItem> statuses = Group(records, "StatusName", "StatusColor");
        List<GroupItem> priorities = Group(records, "PriorityName", "PriorityColor");
        List<GroupItem> situations = Group(records, "SituationName", "SituationColor");

        var statusItems = statuses.Select((item, index) => new
        {
            name = item.Name,
            count = item.Count,
            percent = Percent(item.Count, total),
            color = item.Color,
            bubble = 24 + (int)Math.Round(Math.Sqrt(item.Count) * 7),
            bubbleColor = BubbleColor(index),
            textColor = BubbleTextColor(index),
            fontSize = 12 + Math.Min(20, item.Count),
            x = 8 + ((index * 23) % 74),
            y = 8 + ((index * 31) % 66)
        }).ToList();

        var statusKpis = statuses.Select((item, index) => new
        {
            name = item.Name,
            count = item.Count,
            icon = StatusIcon(item.Name),
            color = item.Color
        }).ToList();

        double assignedHours = records.Sum(row => DurationHours(Value(row, "AssignedDuration")));
        double spentHours = records.Sum(row => Number(row, "SpentHours"));
        double completion = total == 0 ? 0 : records.Average(row => Math.Max(0, Math.Min(100, Number(row, "CompletionPercent"))));
        int totalIssues = records.Sum(row => (int)Number(row, "TotalIssues"));
        int resolvedIssues = records.Sum(row => (int)Number(row, "ResolvedIssues"));

        var now = DateTime.Today;
        var hourDays = BuildHours(records, rangeStart, rangeEnd);
        var priorityItems = BuildChartItems(priorities, total);
        var situationItems = BuildChartItems(situations, total);
        var issueItems = new[]
        {
            new { name = "Issues", count = totalIssues, color = "#ff999a" },
            new { name = "Resolved", count = resolvedIssues, color = "#a5c7ff" }
        };

        return new
        {
            userName = CurrentUserName(),
            asOf = now,
            statuses = statusKpis,
            taskStatus = new { total = total, items = statusItems },
            priority = new { total = total, items = priorityItems, gradient = Gradient(priorities.Select(x => x.Count).ToList(), priorities.Select(x => x.Color).ToList()) },
            situation = new { total = total, items = situationItems, gradient = Gradient(situations.Select(x => x.Count).ToList(), situations.Select(x => x.Color).ToList()) },
            hours = new { days = hourDays },
            taskEfficiency = Math.Round(completion),
            timeEfficiency = spentHours <= 0 ? 0 : Math.Round(Math.Min(100, assignedHours / spentHours * 100)),
            tags = BuildTagCounts(records, regId),
            issues = new { total = totalIssues, items = issueItems, gradient = Gradient(new List<int> { Math.Max(0, totalIssues - resolvedIssues), resolvedIssues }, new List<string> { "#ff999a", "#a5c7ff" }) }
        };
    }

    private static List<object> BuildTagCounts(List<DataRow> records, string regId)
    {
        var tagIds = new HashSet<int>();
        foreach (DataRow row in records)
        {
            foreach (string part in Value(row, "TagIds").Split(','))
            {
                int id;
                if (Int32.TryParse(part.Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out id) && id > 0)
                    tagIds.Add(id);
            }
        }

        if (tagIds.Count == 0) return new List<object>();

        var counts = new Dictionary<int, int>();
        foreach (DataRow row in records)
        {
            var rowTagIds = new HashSet<int>();
            foreach (string part in Value(row, "TagIds").Split(','))
            {
                int id;
                if (Int32.TryParse(part.Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out id) && id > 0)
                    rowTagIds.Add(id);
            }
            foreach (int id in rowTagIds)
                counts[id] = counts.ContainsKey(id) ? counts[id] + 1 : 1;
        }

        string idList = String.Join(",", tagIds.Select(id => id.ToString(CultureInfo.InvariantCulture)).ToArray());
        string safeRegId = (regId ?? String.Empty).Replace("'", "''");
        string sql = "SELECT id, Tags, TagsColor FROM dbo.Pms_tbl_Addtags WITH (NOLOCK) " +
                     "WHERE status=1 AND archive=0 AND regid='" + safeRegId + "' AND id IN (" + idList + ")";
        DataSet tagData;
        try { tagData = new DataAccess().GetDataSetInline(sql); }
        catch { return new List<object>(); }
        if (tagData == null || tagData.Tables.Count == 0) return new List<object>();

        var result = new List<TagCountItem>();
        foreach (DataRow tag in tagData.Tables[0].Rows)
        {
            int id;
            if (!Int32.TryParse(Convert.ToString(tag["id"], CultureInfo.InvariantCulture), out id) || !counts.ContainsKey(id))
                continue;
            string name = Convert.ToString(tag["Tags"], CultureInfo.InvariantCulture);
            string color = Convert.ToString(tag["TagsColor"], CultureInfo.InvariantCulture);
            result.Add(new TagCountItem { Name = name, Color = String.IsNullOrWhiteSpace(color) ? "#000" : color, Count = counts[id] });
        }
        return result.OrderByDescending(item => item.Count)
            .ThenBy(item => item.Name, StringComparer.OrdinalIgnoreCase)
            .Select(item => (object)new { name = item.Name, color = item.Color, count = item.Count }).ToList();
    }

    private static List<GroupItem> Group(List<DataRow> rows, string nameColumn, string colorColumn)
    {
        return rows.GroupBy(row => String.IsNullOrWhiteSpace(Value(row, nameColumn)) ? "Unspecified" : Value(row, nameColumn), StringComparer.OrdinalIgnoreCase)
            .Select(group => new GroupItem
            {
                Name = group.Key,
                Count = group.Count(),
                Color = String.IsNullOrWhiteSpace(Value(group.First(), colorColumn)) ? "#a5c7ff" : Value(group.First(), colorColumn)
            }).OrderByDescending(item => item.Count).ToList();
    }

    private static List<object> BuildChartItems(List<GroupItem> groups, int total)
    {
        return groups.Select(item => (object)new { name = item.Name, count = item.Count, percent = Percent(item.Count, total), color = item.Color }).ToList();
    }

    private static List<object> BuildHours(List<DataRow> rows, DateTime rangeStart, DateTime rangeEnd)
    {
        int spanDays = Math.Max(1, (rangeEnd.Date - rangeStart.Date).Days + 1);
        var results = new List<object>();
        if (spanDays <= 14)
        {
            for (DateTime date = rangeStart.Date; date <= rangeEnd.Date; date = date.AddDays(1))
            {
                List<DataRow> dayRows = rows.Where(row => DateValue(row, "AssignmentStart", "AssignedAt").Date == date.Date).ToList();
                string dayLabel = spanDays == 1 ? "Today" : date.ToString("ddd", CultureInfo.InvariantCulture);
                results.Add(new { day = dayLabel, assigned = Math.Round(dayRows.Sum(row => DurationHours(Value(row, "AssignedDuration"))), 2), spent = Math.Round(dayRows.Sum(row => Number(row, "SpentHours")), 2) });
            }
            return results;
        }

        if (spanDays <= 62)
        {
            for (DateTime start = rangeStart.Date; start <= rangeEnd.Date; start = start.AddDays(7))
            {
                DateTime end = start.AddDays(6) < rangeEnd.Date ? start.AddDays(6) : rangeEnd.Date;
                List<DataRow> bucket = rows.Where(row => { DateTime d = DateValue(row, "AssignmentStart", "AssignedAt").Date; return d >= start && d <= end; }).ToList();
                results.Add(new { day = start.ToString("dd MMM", CultureInfo.InvariantCulture), assigned = Math.Round(bucket.Sum(row => DurationHours(Value(row, "AssignedDuration"))), 2), spent = Math.Round(bucket.Sum(row => Number(row, "SpentHours")), 2) });
            }
            return results;
        }

        DateTime monthStart = new DateTime(rangeStart.Year, rangeStart.Month, 1);
        while (monthStart <= rangeEnd.Date)
        {
            DateTime monthEnd = monthStart.AddMonths(1).AddDays(-1);
            List<DataRow> bucket = rows.Where(row => { DateTime d = DateValue(row, "AssignmentStart", "AssignedAt").Date; return d >= monthStart && d <= monthEnd; }).ToList();
            results.Add(new { day = monthStart.ToString("MMM yy", CultureInfo.InvariantCulture), assigned = Math.Round(bucket.Sum(row => DurationHours(Value(row, "AssignedDuration"))), 2), spent = Math.Round(bucket.Sum(row => Number(row, "SpentHours")), 2) });
            monthStart = monthStart.AddMonths(1);
        }
        return results;
    }

    private static string Gradient(List<int> values, List<string> colors)
    {
        int total = values.Sum();
        if (total <= 0 || colors.Count == 0) return "conic-gradient(#e5e9ef 0 100%)";
        var parts = new List<string>();
        double current = 0;
        for (int i = 0; i < values.Count; i++)
        {
            double next = current + values[i] * 100.0 / total;
            parts.Add(colors[i] + " " + current.ToString("0.##", CultureInfo.InvariantCulture) + "% " + next.ToString("0.##", CultureInfo.InvariantCulture) + "%");
            current = next;
        }
        return "conic-gradient(" + String.Join(",", parts) + ")";
    }

    private static int Percent(int count, int total) { return total == 0 ? 0 : (int)Math.Round(count * 100.0 / total); }
    private static double DurationHours(string value) { TimeSpan duration; return TimeSpan.TryParse(value, CultureInfo.InvariantCulture, out duration) ? duration.TotalHours : 0; }
    private static double Number(DataRow row, string column) { double value; return Double.TryParse(Value(row, column), NumberStyles.Any, CultureInfo.InvariantCulture, out value) ? value : 0; }
    private static string Value(DataRow row, string column) { return row.Table.Columns.Contains(column) && row[column] != DBNull.Value ? Convert.ToString(row[column], CultureInfo.InvariantCulture) : ""; }
    private static DateTime DateValue(DataRow row, string primary, string fallback) { DateTime value; string text = Value(row, primary); if (!DateTime.TryParse(text, CultureInfo.InvariantCulture, DateTimeStyles.AssumeLocal, out value)) DateTime.TryParse(Value(row, fallback), CultureInfo.InvariantCulture, DateTimeStyles.AssumeLocal, out value); return value; }
    private static string CurrentUserName() { HttpCookie cookie = HttpContext.Current.Request.Cookies["user"]; return cookie == null ? "User" : (cookie["user_name"] ?? "User"); }
    private static string BubbleColor(int index) { string[] colors = { "#ffe7d8", "#d5ffd7", "#fff4d1", "#ebdbff", "#d9edff" }; return colors[index % colors.Length]; }
    private static string BubbleTextColor(int index) { string[] colors = { "#f96e18", "#00b80e", "#e5ad00", "#8a38f5", "#1682d4" }; return colors[index % colors.Length]; }
    private static string StatusIcon(string name) { string value = (name ?? "").ToLowerInvariant(); if (value.Contains("complete")) return "ri-checkbox-circle-line"; if (value.Contains("progress")) return "ri-hourglass-line"; if (value.Contains("reopen")) return "ri-history-line"; return "ri-folder-open-line"; }

    private sealed class GroupItem { public string Name; public int Count; public string Color; }
    private sealed class TagCountItem { public string Name; public int Count; public string Color; }
}
