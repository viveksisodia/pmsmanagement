using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.Script.Services;
using System.Web.UI;
using CommonClass;

public partial class userdashboard : Page
{
    [WebMethod]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public static object GetUserDashboardData(string fromDate, string toDate)
    {
        HttpCookie tenantCookie = HttpContext.Current.Request.Cookies["cadmin"];
        HttpCookie userCookie = HttpContext.Current.Request.Cookies["user"];
        if (tenantCookie == null || userCookie == null || String.IsNullOrWhiteSpace(tenantCookie["id"]) || String.IsNullOrWhiteSpace(userCookie["user_id"]))
            throw new HttpException(401, "Login information is missing.");

        DateTime globalToday = GetGlobalToday();
        DateTime rangeStart = ParseDashboardDate(fromDate, globalToday.AddDays(-(((int)globalToday.DayOfWeek + 6) % 7)));
        DateTime rangeEnd = ParseDashboardDate(toDate, rangeStart.AddDays(6));
        if (rangeEnd < rangeStart)
        {
            DateTime swap = rangeStart;
            rangeStart = rangeEnd;
            rangeEnd = swap;
        }
        rangeStart = rangeStart.Date;
        rangeEnd = rangeEnd.Date;

        string regId = tenantCookie["id"];
        string userId = userCookie["user_id"];
        SqlParameter[] parameters =
        {
            new SqlParameter("@RegId", regId),
            new SqlParameter("@UserId", userId),
            new SqlParameter("@FromDate", SqlDbType.Date) { Value = rangeStart },
            new SqlParameter("@ToDate", SqlDbType.Date) { Value = rangeEnd }
        };

        DataAccess dataAccess = new DataAccess();
        DataSet data = dataAccess.GetDataSet("dbo.usp_Pms_UserDashboard_GetAssignedSubtasks", parameters);
        DataTable rows = data != null && data.Tables.Count > 0 ? data.Tables[0] : new DataTable();
        return BuildDashboard(rows, rangeStart, rangeEnd, regId, userId);
    }

    [WebMethod]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public static object GetTaskHoursData(string fromDate, string toDate)
    {
        HttpCookie tenantCookie = HttpContext.Current.Request.Cookies["cadmin"];
        HttpCookie userCookie = HttpContext.Current.Request.Cookies["user"];
        if (tenantCookie == null || userCookie == null || String.IsNullOrWhiteSpace(tenantCookie["id"]) || String.IsNullOrWhiteSpace(userCookie["user_id"]))
            throw new HttpException(401, "Login information is missing.");

        DateTime globalToday = GetGlobalToday();
        DateTime rangeStart = ParseDashboardDate(fromDate, globalToday);
        DateTime rangeEnd = ParseDashboardDate(toDate, rangeStart);
        if (rangeEnd < rangeStart)
        {
            DateTime swap = rangeStart;
            rangeStart = rangeEnd;
            rangeEnd = swap;
        }
        rangeStart = rangeStart.Date;
        rangeEnd = rangeEnd.Date;

        SqlParameter[] parameters =
        {
            new SqlParameter("@RegId", tenantCookie["id"]),
            new SqlParameter("@UserId", userCookie["user_id"]),
            new SqlParameter("@FromDate", SqlDbType.Date) { Value = rangeStart },
            new SqlParameter("@ToDate", SqlDbType.Date) { Value = rangeEnd }
        };

        DataAccess dataAccess = new DataAccess();
        DataSet data = dataAccess.GetDataSet("dbo.usp_Pms_UserDashboard_GetAssignedSubtasks", parameters);
        DataTable rows = data != null && data.Tables.Count > 0 ? data.Tables[0] : new DataTable();
        Dictionary<string, double> spentHoursByDate = LoadSpentHoursByDate(tenantCookie["id"], userCookie["user_id"], rangeStart, rangeEnd);
        var shiftCapacity = LoadTaskHoursShift(tenantCookie["id"], userCookie["user_id"]);
        return new { days = BuildHours(rows.Rows.Cast<DataRow>().ToList(), rangeStart, rangeEnd, spentHoursByDate), shiftHours = shiftCapacity.shiftHours, fullShiftHours = shiftCapacity.fullShiftHours, lunchHours = shiftCapacity.lunchHours };
    }
    public static DataRow checkonleave(string regId, string userId, string leavedate)
    {
        DataRow dr = null;

        try
        {
            SqlParameter[] parameters =
            {
            new SqlParameter("@regid", regId),
            new SqlParameter("@uidd", userId),
            new SqlParameter("@CheckDate", leavedate)
            };

            DataAccess dataAccess = new DataAccess();
            DataSet data = dataAccess.GetDataSet("dbo.pms_GetEmployeeLeaveDetails", parameters);
            if (data != null &&data.Tables.Count > 0 &&data.Tables[0].Rows.Count > 0)
            {
                dr = data.Tables[0].Rows[0];
            }
        }
        catch (Exception ex)
        {
            // Log ex using your existing logging method.
        }

        return dr;
    }
    private static TaskHoursShift LoadTaskHoursShift(string regId, string userId)
    {
        int tenantId, employeeId;
        if (!Int32.TryParse(regId, out tenantId) || !Int32.TryParse(userId, out employeeId))
            throw new HttpException(401, "Login information is invalid.");
        DataAccess da = new DataAccess();
        DataSet shift = da.GetDataSetInline(@"
select top(1) shft.starttime, shft.endtime, isnull(shft.lunchbreak,0) as lunchbreak
from tbl_employee emp with(nolock)
inner join tbl_shift shft with(nolock) on emp.ShiftType = shft.id
where emp.status=1 and emp.archive=0 and emp.regid=" + tenantId + " and emp.id=" + employeeId);
        // Same fallback as Weekly View when no shift is configured.
        TimeSpan start = new TimeSpan(9, 0, 0), end = new TimeSpan(18, 0, 0);
        double lunchMinutes = 0;
        if (shift != null && shift.Tables.Count > 0 && shift.Tables[0].Rows.Count > 0)
        {
            start = ParseTaskHoursShiftTime(shift.Tables[0].Rows[0]["starttime"].ToString(), start);
            end = ParseTaskHoursShiftTime(shift.Tables[0].Rows[0]["endtime"].ToString(), end);
            double parsedLunch;
            if (Double.TryParse(shift.Tables[0].Rows[0]["lunchbreak"].ToString(), NumberStyles.Number, CultureInfo.InvariantCulture, out parsedLunch))
                lunchMinutes = Math.Max(0, parsedLunch);
        }
        double minutes = (end - start).TotalMinutes;
        if (minutes <= 0) minutes += 24 * 60;
        return new TaskHoursShift {
            shiftHours = Math.Max(0, minutes - Math.Min(lunchMinutes, minutes)) / 60.0,
            fullShiftHours = minutes / 60.0,
            lunchHours = Math.Min(lunchMinutes, minutes) / 60.0
        };
    }

    private sealed class TaskHoursShift
    {
        public double shiftHours { get; set; }
        public double fullShiftHours { get; set; }
        public double lunchHours { get; set; }
    }

    private static TimeSpan ParseTaskHoursShiftTime(string value, TimeSpan fallback)
    {
        DateTime parsed;
        string[] formats = { "hh:mm tt", "h:mm tt", "HH:mm", "HH:mm:ss", "H:mm", "H:mm:ss" };
        if (!String.IsNullOrWhiteSpace(value) &&
            (DateTime.TryParseExact(value.Trim(), formats, CultureInfo.InvariantCulture,
                DateTimeStyles.AllowWhiteSpaces, out parsed) || DateTime.TryParse(value, out parsed)))
            return parsed.TimeOfDay;
        return fallback;
    }

    private static DateTime GetGlobalToday()
    {
        TimeZoneInfo globalTimeZone;
        try
        {
            globalTimeZone = TimeZoneInfo.FindSystemTimeZoneById("Arabian Standard Time");
        }
        catch (TimeZoneNotFoundException)
        {
            globalTimeZone = TimeZoneInfo.FindSystemTimeZoneById("Asia/Dubai");
        }
        return TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, globalTimeZone).Date;
    }

    private static DateTime ParseDashboardDate(string value, DateTime fallback)
    {
        DateTime result;
        return DateTime.TryParseExact(value, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out result) ? result.Date : fallback.Date;
    }

    private static IssueSummary LoadIssueSummary(string regId, string userId, DateTime rangeStart, DateTime rangeEnd)
    {
        var summary = new IssueSummary();
        int regIdValue;
        int userIdValue;
        if (!Int32.TryParse(regId, NumberStyles.Integer, CultureInfo.InvariantCulture, out regIdValue) ||
            !Int32.TryParse(userId, NumberStyles.Integer, CultureInfo.InvariantCulture, out userIdValue))
            return summary;

        string from = rangeStart.Date.ToString("yyyyMMdd", CultureInfo.InvariantCulture);
        string to = rangeEnd.Date.ToString("yyyyMMdd", CultureInfo.InvariantCulture);
        string employee = userIdValue.ToString(CultureInfo.InvariantCulture);
        string sql = @"
SELECT COUNT(DISTINCT i.id) AS TotalIssues,
       COUNT(DISTINCT CASE WHEN ISNULL(ps.iscomplete, 0) = 1 THEN i.id END) AS ResolvedIssues
FROM dbo.Pms_tbl_Addissues i WITH (NOLOCK)
LEFT JOIN dbo.Pms_tbl_Projectstatus ps WITH (NOLOCK)
  ON ps.id = i.IssueStatus AND ps.regid = i.regid AND ps.status = 1 AND ps.archive = 0
WHERE i.regid = " + regIdValue.ToString(CultureInfo.InvariantCulture) + @"
  AND i.status = 1 AND i.archive = 0
  AND ISNULL(i.cdate, i.StartDate) >= CONVERT(date, '" + from + @"', 112)
  AND ISNULL(i.cdate, i.StartDate) < DATEADD(day, 1, CONVERT(date, '" + to + @"', 112))
  AND " + IssueEmployeeMatchClause(employee);

        DataSet data = new DataAccess().GetDataSetInline(sql);
        if (data != null && data.Tables.Count > 0 && data.Tables[0].Rows.Count > 0)
        {
            DataRow row = data.Tables[0].Rows[0];
            summary.Total = (int)Number(row, "TotalIssues");
            summary.Resolved = (int)Number(row, "ResolvedIssues");
        }
        return summary;
    }

    private static string IssueEmployeeMatchClause(string employee)
    {
        string pattern = "(',' + REPLACE(REPLACE(REPLACE(ISNULL(CONVERT(nvarchar(2000),{0}),''),' ',''),';',','),'|',',') + ',') LIKE '%," + employee + ",%'";
        return "(TRY_CONVERT(int,i.Owner)=" + employee +
               " OR " + String.Format(CultureInfo.InvariantCulture, pattern, "i.Owner") +
               " OR TRY_CONVERT(int,i.AssignTo)=" + employee +
               " OR " + String.Format(CultureInfo.InvariantCulture, pattern, "i.AssignTo") +
               " OR " + String.Format(CultureInfo.InvariantCulture, pattern, "i.team") + ")";
    }

    private static object BuildDashboard(DataTable rows, DateTime rangeStart, DateTime rangeEnd, string regId, string userId)
    {
        List<DataRow> records = rows.Rows.Cast<DataRow>().ToList();
        int total = records.Count;
        List<GroupItem> statuses = Group(records, "StatusName", "StatusColor");
        List<GroupItem> priorities = Group(records, "PriorityName", "PriorityColor");
        List<GroupItem> situations = Group(records, "SituationName", "SituationColor");

        var statusItems = statuses.Select((item, index) => new
        {
            name = item.Name,
            count = item.Count,
            percent = Percent(item.Count, total),
            color = item.Color,
            bubble = 24 + (int)Math.Round(Math.Sqrt(item.Count) * 7),
            bubbleColor = BubbleColor(index),
            textColor = BubbleTextColor(index),
            fontSize = 12 + Math.Min(20, item.Count),
            x = 8 + ((index * 23) % 74),
            y = 8 + ((index * 31) % 66)
        }).ToList();

        var statusKpis = statuses.Select((item, index) => new
        {
            name = item.Name,
            count = item.Count,
            icon = StatusIcon(item.Name),
            color = item.Color
        }).ToList();

        Dictionary<string, double> spentHoursByDate = LoadSpentHoursByDate(regId, HttpContext.Current.Request.Cookies["user"]["user_id"], rangeStart, rangeEnd);
        double timeEfficiency = CalculateAverageTimeEfficiency(records, regId, userId);
        int totalAssignedSubtasks = records.Count;
        int completedSubtasks = records.Count(IsCompletedSubtask);
        double completion = totalAssignedSubtasks == 0
            ? 0
            : (completedSubtasks * 100.0) / totalAssignedSubtasks;
        IssueSummary issueSummary = LoadIssueSummary(regId, userId, rangeStart, rangeEnd);
        int totalIssues = issueSummary.Total;
        int resolvedIssues = issueSummary.Resolved;

        var now = GetGlobalToday();
        var hourDays = BuildHours(records, rangeStart, rangeEnd, spentHoursByDate);
        var priorityItems = BuildChartItems(priorities, total);
        var situationItems = BuildChartItems(situations, total);
        var issueItems = new[]
        {
            new { name = "Issues", count = totalIssues, color = "#ff999a" },
            new { name = "Resolved", count = resolvedIssues, color = "#a5c7ff" }
        };

        var shiftCapacity = LoadTaskHoursShift(regId, userId);
        return new
        {
            userName = CurrentUserName(),
            asOf = now,
            statuses = statusKpis,
            taskStatus = new { total = total, items = statusItems },
            priority = new { total = total, items = priorityItems, gradient = Gradient(priorities.Select(x => x.Count).ToList(), priorities.Select(x => x.Color).ToList()) },
            situation = new { total = total, items = situationItems, gradient = Gradient(situations.Select(x => x.Count).ToList(), situations.Select(x => x.Color).ToList()) },
            hours = new { days = hourDays, shiftHours = shiftCapacity.shiftHours, fullShiftHours = shiftCapacity.fullShiftHours, lunchHours = shiftCapacity.lunchHours },
            taskEfficiency = Math.Round(completion),
            timeEfficiency = timeEfficiency,
            tags = BuildTagCounts(records, regId),
            issues = new { total = totalIssues, items = issueItems, gradient = Gradient(new List<int> { Math.Max(0, totalIssues - resolvedIssues), resolvedIssues }, new List<string> { "#ff999a", "#a5c7ff" }) }
        };
    }

    private static List<object> BuildTagCounts(List<DataRow> records, string regId)
    {
        var tagIds = new HashSet<int>();
        foreach (DataRow row in records)
        {
            foreach (string part in Value(row, "TagIds").Split(','))
            {
                int id;
                if (Int32.TryParse(part.Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out id) && id > 0)
                    tagIds.Add(id);
            }
        }

        if (tagIds.Count == 0) return new List<object>();

        var counts = new Dictionary<int, int>();
        foreach (DataRow row in records)
        {
            var rowTagIds = new HashSet<int>();
            foreach (string part in Value(row, "TagIds").Split(','))
            {
                int id;
                if (Int32.TryParse(part.Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out id) && id > 0)
                    rowTagIds.Add(id);
            }
            foreach (int id in rowTagIds)
                counts[id] = counts.ContainsKey(id) ? counts[id] + 1 : 1;
        }

        string idList = String.Join(",", tagIds.Select(id => id.ToString(CultureInfo.InvariantCulture)).ToArray());
        string safeRegId = (regId ?? String.Empty).Replace("'", "''");
        string sql = "SELECT id, Tags, TagsColor FROM dbo.Pms_tbl_Addtags WITH (NOLOCK) " +
                     "WHERE status=1 AND archive=0 AND regid='" + safeRegId + "' AND id IN (" + idList + ")";
        DataSet tagData;
        try { tagData = new DataAccess().GetDataSetInline(sql); }
        catch { return new List<object>(); }
        if (tagData == null || tagData.Tables.Count == 0) return new List<object>();

        var result = new List<TagCountItem>();
        foreach (DataRow tag in tagData.Tables[0].Rows)
        {
            int id;
            if (!Int32.TryParse(Convert.ToString(tag["id"], CultureInfo.InvariantCulture), out id) || !counts.ContainsKey(id))
                continue;
            string name = Convert.ToString(tag["Tags"], CultureInfo.InvariantCulture);
            string color = Convert.ToString(tag["TagsColor"], CultureInfo.InvariantCulture);
            result.Add(new TagCountItem { Name = name, Color = String.IsNullOrWhiteSpace(color) ? "#000" : color, Count = counts[id] });
        }
        return result.OrderByDescending(item => item.Count)
            .ThenBy(item => item.Name, StringComparer.OrdinalIgnoreCase)
            .Select(item => (object)new { name = item.Name, color = item.Color, count = item.Count }).ToList();
    }

    private static List<GroupItem> Group(List<DataRow> rows, string nameColumn, string colorColumn)
    {
        return rows.GroupBy(row => String.IsNullOrWhiteSpace(Value(row, nameColumn)) ? "Unspecified" : Value(row, nameColumn), StringComparer.OrdinalIgnoreCase)
            .Select(group => new GroupItem
            {
                Name = group.Key,
                Count = group.Count(),
                Color = String.IsNullOrWhiteSpace(Value(group.First(), colorColumn)) ? "#a5c7ff" : Value(group.First(), colorColumn)
            }).OrderByDescending(item => item.Count).ToList();
    }

    private static List<object> BuildChartItems(List<GroupItem> groups, int total)
    {
        return groups.Select(item => (object)new { name = item.Name, count = item.Count, percent = Percent(item.Count, total), color = item.Color }).ToList();
    }

    private static double CalculateAverageTimeEfficiency(List<DataRow> records, string regId, string userId)
    {
        var completedBySubtask = records
            .Where(IsCompletedSubtask)
            .Select(row => new { SubtaskId = GetSubtaskId(row), AssignedHours = DurationHours(Value(row, "AssignedDuration")) })
            .Where(item => item.SubtaskId > 0 && item.AssignedHours > 0)
            .GroupBy(item => item.SubtaskId)
            .Select(group => new { SubtaskId = group.Key, AssignedHours = group.Max(item => item.AssignedHours) })
            .ToList();

        if (completedBySubtask.Count == 0) return 0;

        Dictionary<int, double> completeHoursBySubtask = LoadCompleteHoursBySubtask(
            regId, userId, completedBySubtask.Select(item => item.SubtaskId).Distinct().ToList());

        List<double> efficiencies = completedBySubtask
            .Select(item =>
            {
                double spentHours;
                if (!completeHoursBySubtask.TryGetValue(item.SubtaskId, out spentHours) || spentHours <= 0)
                    return 0.0;
                return item.AssignedHours / spentHours * 100.0;
            })
            .ToList();

        return efficiencies.Count == 0 ? 0 : Math.Round(efficiencies.Average());
    }

    private static int GetSubtaskId(DataRow row)
    {
        string[] columns = { "SubTaskId", "subtaskid", "SubtaskId", "Id", "id" };
        foreach (string column in columns)
        {
            if (!row.Table.Columns.Contains(column) || row[column] == DBNull.Value) continue;
            int id;
            if (Int32.TryParse(Convert.ToString(row[column], CultureInfo.InvariantCulture), NumberStyles.Integer, CultureInfo.InvariantCulture, out id) && id > 0)
                return id;
        }
        return 0;
    }

    private static Dictionary<int, double> LoadCompleteHoursBySubtask(string regId, string userId, List<int> subtaskIds)
    {
        var result = new Dictionary<int, double>();
        int regIdValue;
        int userIdValue;
        if (subtaskIds == null || subtaskIds.Count == 0 ||
            !Int32.TryParse(regId, NumberStyles.Integer, CultureInfo.InvariantCulture, out regIdValue) ||
            !Int32.TryParse(userId, NumberStyles.Integer, CultureInfo.InvariantCulture, out userIdValue))
            return result;

        string idList = String.Join(",", subtaskIds.Distinct().Where(id => id > 0)
            .Select(id => id.ToString(CultureInfo.InvariantCulture)).ToArray());
        if (String.IsNullOrWhiteSpace(idList)) return result;

        // The dashboard's selected period has already filtered the completed assignment rows.
        // Compare each task's assigned duration with its full recorded timer duration.
        string sql = @"
SELECT subtaskid AS SubTaskId,
       ISNULL(SUM(CAST(ISNULL(PausedTime, 0) AS numeric(18,2))), 0) AS TotalMinutes
FROM Pms_Tbl_PauseStatus WITH (NOLOCK)
WHERE status = 1
  AND archive = 0
  AND regid = " + regIdValue.ToString(CultureInfo.InvariantCulture) + @"
  AND uid = " + userIdValue.ToString(CultureInfo.InvariantCulture) + @"
  AND LOWER(ISNULL(type, 'subtask')) = 'subtask'
  AND ISNULL(subtaskid, 0) IN (" + idList + @")
  AND ISNULL(entrytype, '') IN ('pause', 'stop')
  AND ISNUMERIC(ISNULL(PausedTime, 0)) = 1
GROUP BY subtaskid";

        DataSet data = new DataAccess().GetDataSetInline(sql);
        if (data == null || data.Tables.Count == 0) return result;
        foreach (DataRow row in data.Tables[0].Rows)
        {
            int subtaskId;
            if (!Int32.TryParse(Value(row, "SubTaskId"), NumberStyles.Integer, CultureInfo.InvariantCulture, out subtaskId) || subtaskId <= 0)
                continue;
            result[subtaskId] = Math.Max(0, Number(row, "TotalMinutes") / 60.0);
        }
        return result;
    }

    private static Dictionary<string, double> LoadSpentHoursByDate(string regId, string userId, DateTime rangeStart, DateTime rangeEnd)
    {
        var result = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);
        int regIdValue;
        int userIdValue;
        if (!Int32.TryParse(regId, NumberStyles.Integer, CultureInfo.InvariantCulture, out regIdValue) ||
            !Int32.TryParse(userId, NumberStyles.Integer, CultureInfo.InvariantCulture, out userIdValue))
            return result;

        DateTime endExclusive = rangeEnd.Date.AddDays(1);
        string startSql = rangeStart.Date.ToString("yyyyMMdd", CultureInfo.InvariantCulture);
        string endSql = endExclusive.ToString("yyyyMMdd", CultureInfo.InvariantCulture);
        string sql = @"
SELECT CONVERT(varchar(10), CAST(StartDatetime AS date), 23) AS WorkDate,
       ISNULL(SUM(CAST(ISNULL(PausedTime, 0) AS numeric(18,2))), 0) AS TotalMinutes
FROM Pms_Tbl_PauseStatus WITH (NOLOCK)
WHERE status = 1
  AND archive = 0
  AND regid = " + regIdValue.ToString(CultureInfo.InvariantCulture) + @"
  AND uid = " + userIdValue.ToString(CultureInfo.InvariantCulture) + @"
  AND StartDatetime >= CONVERT(datetime, '" + startSql + @"', 112)
  AND StartDatetime < CONVERT(datetime, '" + endSql + @"', 112)
  AND ISNULL(entrytype, '') IN ('pause', 'stop')
  AND ISNUMERIC(ISNULL(PausedTime, 0)) = 1
GROUP BY CAST(StartDatetime AS date)";

        DataSet data = new DataAccess().GetDataSetInline(sql);
        if (data == null || data.Tables.Count == 0) return result;

        foreach (DataRow row in data.Tables[0].Rows)
        {
            DateTime workDate;
            if (!DateTime.TryParse(Value(row, "WorkDate"), CultureInfo.InvariantCulture, DateTimeStyles.None, out workDate))
                continue;
            double totalMinutes = Number(row, "TotalMinutes");
            result[workDate.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture)] = Math.Max(0, totalMinutes / 60.0);
        }
        return result;
    }

    private static List<object> BuildHours(List<DataRow> rows, DateTime rangeStart, DateTime rangeEnd, IDictionary<string, double> spentHoursByDate)
    {
        spentHoursByDate = spentHoursByDate ?? new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);
        int spanDays = Math.Max(1, (rangeEnd.Date - rangeStart.Date).Days + 1);
        var results = new List<object>();
        if (spanDays <= 14)
        {
            for (DateTime date = rangeStart.Date; date <= rangeEnd.Date; date = date.AddDays(1))
            {
                List<DataRow> dayRows = rows.Where(row => DateValue(row, "AssignmentStart", "AssignedAt").Date == date.Date).ToList();
                string dayLabel = spanDays == 1 ? "Today" : date.ToString("ddd", CultureInfo.InvariantCulture);
                string key = date.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
                double spent = spentHoursByDate.ContainsKey(key) ? spentHoursByDate[key] : 0;
                results.Add(new { day = dayLabel, assigned = Math.Round(dayRows.Sum(row => DurationHours(Value(row, "AssignedDuration"))), 2), spent = Math.Round(spent, 2) });
            }
            return results;
        }

        if (spanDays <= 62)
        {
            for (DateTime start = rangeStart.Date; start <= rangeEnd.Date; start = start.AddDays(7))
            {
                DateTime end = start.AddDays(6) < rangeEnd.Date ? start.AddDays(6) : rangeEnd.Date;
                List<DataRow> bucket = rows.Where(row => { DateTime d = DateValue(row, "AssignmentStart", "AssignedAt").Date; return d >= start && d <= end; }).ToList();
                double spent = spentHoursByDate.Where(item => { DateTime d; return DateTime.TryParseExact(item.Key, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out d) && d.Date >= start && d.Date <= end; }).Sum(item => item.Value);
                results.Add(new { day = start.ToString("dd MMM", CultureInfo.InvariantCulture), assigned = Math.Round(bucket.Sum(row => DurationHours(Value(row, "AssignedDuration"))), 2), spent = Math.Round(spent, 2) });
            }
            return results;
        }

        DateTime monthStart = new DateTime(rangeStart.Year, rangeStart.Month, 1);
        while (monthStart <= rangeEnd.Date)
        {
            DateTime monthEnd = monthStart.AddMonths(1).AddDays(-1);
            List<DataRow> bucket = rows.Where(row => { DateTime d = DateValue(row, "AssignmentStart", "AssignedAt").Date; return d >= monthStart && d <= monthEnd; }).ToList();
            double spent = spentHoursByDate.Where(item => { DateTime d; return DateTime.TryParseExact(item.Key, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out d) && d.Date >= monthStart && d.Date <= monthEnd; }).Sum(item => item.Value);
            results.Add(new { day = monthStart.ToString("MMM yy", CultureInfo.InvariantCulture), assigned = Math.Round(bucket.Sum(row => DurationHours(Value(row, "AssignedDuration"))), 2), spent = Math.Round(spent, 2) });
            monthStart = monthStart.AddMonths(1);
        }
        return results;
    }

    private static string Gradient(List<int> values, List<string> colors)
    {
        int total = values.Sum();
        if (total <= 0 || colors.Count == 0) return "conic-gradient(#e5e9ef 0 100%)";
        var parts = new List<string>();
        double current = 0;
        for (int i = 0; i < values.Count; i++)
        {
            double next = current + values[i] * 100.0 / total;
            parts.Add(colors[i] + " " + current.ToString("0.##", CultureInfo.InvariantCulture) + "% " + next.ToString("0.##", CultureInfo.InvariantCulture) + "%");
            current = next;
        }
        return "conic-gradient(" + String.Join(",", parts) + ")";
    }

    private static int Percent(int count, int total) { return total == 0 ? 0 : (int)Math.Round(count * 100.0 / total); }
    private static double DurationHours(string value) { TimeSpan duration; return TimeSpan.TryParse(value, CultureInfo.InvariantCulture, out duration) ? duration.TotalHours : 0; }
    private static bool IsCompletedSubtask(DataRow row)
    {
        if (row.Table.Columns.Contains("IsComplete") && row["IsComplete"] != DBNull.Value)
        {
            bool completeFlag;
            if (Boolean.TryParse(Convert.ToString(row["IsComplete"], CultureInfo.InvariantCulture), out completeFlag))
                return completeFlag;
            return Number(row, "IsComplete") != 0;
        }

        string status = Value(row, "StatusName").Trim();
        if (status.Equals("Complete", StringComparison.OrdinalIgnoreCase) ||
            status.Equals("Completed", StringComparison.OrdinalIgnoreCase) ||
            status.Equals("Done", StringComparison.OrdinalIgnoreCase) ||
            status.Equals("Closed", StringComparison.OrdinalIgnoreCase))
            return true;

        return Number(row, "CompletionPercent") >= 100;
    }

    private static double Number(DataRow row, string column) { double value; return Double.TryParse(Value(row, column), NumberStyles.Any, CultureInfo.InvariantCulture, out value) ? value : 0; }
    private static string Value(DataRow row, string column) { return row.Table.Columns.Contains(column) && row[column] != DBNull.Value ? Convert.ToString(row[column], CultureInfo.InvariantCulture) : ""; }
    private static DateTime DateValue(DataRow row, string primary, string fallback) { DateTime value; string text = Value(row, primary); if (!DateTime.TryParse(text, CultureInfo.InvariantCulture, DateTimeStyles.AssumeLocal, out value)) DateTime.TryParse(Value(row, fallback), CultureInfo.InvariantCulture, DateTimeStyles.AssumeLocal, out value); return value; }
    private static string CurrentUserName() { HttpCookie cookie = HttpContext.Current.Request.Cookies["user"]; return cookie == null ? "User" : (cookie["user_name"] ?? "User"); }
    private static string BubbleColor(int index) { string[] colors = { "#ffe7d8", "#d5ffd7", "#fff4d1", "#ebdbff", "#d9edff" }; return colors[index % colors.Length]; }
    private static string BubbleTextColor(int index) { string[] colors = { "#f96e18", "#00b80e", "#e5ad00", "#8a38f5", "#1682d4" }; return colors[index % colors.Length]; }
    private static string StatusIcon(string name) { string value = (name ?? "").ToLowerInvariant(); if (value.Contains("complete")) return "ri-checkbox-circle-line"; if (value.Contains("progress")) return "ri-hourglass-line"; if (value.Contains("reopen")) return "ri-history-line"; return "ri-folder-open-line"; }

    private sealed class IssueSummary { public int Total; public int Resolved; }
    private sealed class GroupItem { public string Name; public int Count; public string Color; }
    private sealed class TagCountItem { public string Name; public int Count; public string Color; }
   
}
