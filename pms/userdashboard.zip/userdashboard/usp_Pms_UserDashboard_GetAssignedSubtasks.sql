CREATE OR ALTER PROCEDURE dbo.usp_Pms_UserDashboard_GetAssignedSubtasks
(
    @RegId   NVARCHAR(50),
    @UserId  NVARCHAR(50),
    @FromDate DATE,
    @ToDate   DATE
)
AS
BEGIN
    SET NOCOUNT ON;

    ;WITH ActiveAssignedSubtasks AS
    (
        SELECT
            a.id AS AssignmentId,
            a.subtaskid AS SubtaskId,
            a.projectid AS ProjectId,
            a.milestoneid AS MilestoneId,
            a.taskid AS TaskId,
            a.ownerid AS OwnerId,
            a.taskduration AS AssignedDuration,
            a.startdatetime AS AssignmentStart,
            COALESCE(a.assigndatetime, a.cdate) AS AssignedAt,
            ROW_NUMBER() OVER
            (
                PARTITION BY a.subtaskid
                ORDER BY ISNULL(a.assigndatetime, a.cdate) DESC, a.id DESC
            ) AS RowNumber
        FROM dbo.Pms_tbl_assigntasks AS a WITH (NOLOCK)
        INNER JOIN dbo.Pms_tbl_AddSubTask AS st WITH (NOLOCK)
            ON st.id = a.subtaskid
           AND st.regid = @RegId
           AND st.status = 1
           AND st.archive = 0
        WHERE a.regid = @RegId
          AND a.ownerid = @UserId
          AND LOWER(a.tasktype) = 'subtask'
          AND a.status = 1
          AND a.archive = 0
          AND COALESCE(a.startdatetime, a.assigndatetime, a.cdate) >= @FromDate
          AND COALESCE(a.startdatetime, a.assigndatetime, a.cdate) < DATEADD(DAY, 1, @ToDate)
    )
    SELECT
        a.AssignmentId,
        a.SubtaskId,
        st.Subtaskname,
        a.ProjectId,
        a.MilestoneId,
        a.TaskId,
        a.OwnerId,
        a.AssignedDuration,
        a.AssignmentStart,
        a.AssignedAt,
        ISNULL(st.tagids, '') AS TagIds,
        st.P_Status AS StatusId,
        ISNULL(ps.ProjectStatus, 'Unknown') AS StatusName,
        ISNULL(ps.PrintColor, '#8a94a6') AS StatusColor,
        ISNULL(ps.iscomplete, 0) AS StatusIsComplete,
        st.Priority AS PriorityId,
        ISNULL(pr.name, 'Unspecified') AS PriorityName,
        ISNULL(pr.PrintColor, '#a5c7ff') AS PriorityColor,
        ISNULL(st.CriticalLabelId, 0) AS CriticalLabelId,
        ISNULL(cl.CriticalLabel, 'Unlabelled') AS SituationName,
        ISNULL(cl.ColorCode, '#ffe696') AS SituationColor,
        ISNULL(st.iscompletepercentage, CASE WHEN ISNULL(st.iscomplete, 0) = 1 THEN 100 ELSE 0 END) AS CompletionPercent,
        ISNULL(st.Budget, 0) AS BudgetHours,
        ISNULL(st.Actual, 0) AS SpentHours,
        ISNULL(issues.TotalIssues, 0) AS TotalIssues,
        ISNULL(issues.ResolvedIssues, 0) AS ResolvedIssues
    FROM ActiveAssignedSubtasks AS a
    INNER JOIN dbo.Pms_tbl_AddSubTask AS st WITH (NOLOCK)
        ON st.id = a.SubtaskId
       AND st.regid = @RegId
       AND st.status = 1
       AND st.archive = 0
    LEFT JOIN dbo.Pms_tbl_Projectstatus AS ps WITH (NOLOCK)
        ON ps.id = st.P_Status
       AND ps.regid = @RegId
       AND ps.status = 1
       AND ps.archive = 0
    LEFT JOIN dbo.Pms_tbl_Priority AS pr WITH (NOLOCK)
        ON pr.id = st.Priority
       AND pr.regid = @RegId
       AND pr.status = 1
       AND pr.archive = 0
    LEFT JOIN dbo.Pms_tbl_CriticalLabel AS cl WITH (NOLOCK)
        ON cl.id = st.CriticalLabelId
       AND cl.regid = @RegId
       AND cl.status = 1
       AND cl.archive = 0
    OUTER APPLY
    (
        SELECT
            COUNT(*) AS TotalIssues,
            SUM(CASE WHEN ISNULL(issueStatus.iscomplete, 0) = 1 THEN 1 ELSE 0 END) AS ResolvedIssues
        FROM dbo.Pms_tbl_Addissues AS i WITH (NOLOCK)
        LEFT JOIN dbo.Pms_tbl_Projectstatus AS issueStatus WITH (NOLOCK)
            ON issueStatus.id = i.IssueStatus
           AND issueStatus.regid = @RegId
           AND issueStatus.status = 1
           AND issueStatus.archive = 0
        WHERE i.subtaskid = a.SubtaskId
          AND LOWER(i.Issueon) = 'subtask'
          AND i.status = 1
          AND i.archive = 0
    ) AS issues
    WHERE a.RowNumber = 1
    ORDER BY ISNULL(a.AssignmentStart, a.AssignedAt) DESC, a.SubtaskId;
END;
GO
