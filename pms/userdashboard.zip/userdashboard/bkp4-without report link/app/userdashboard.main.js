(function () {
    'use strict';

    angular.module('pmsUserDashboardApp', ['pmsUserDashboard.services'])
        .directive('udHoursTooltip', ['$timeout', function ($timeout) {
            return {
                restrict: 'A',
                link: function (scope, element, attrs) {
                    var timer = $timeout(function () {
                        var node = element[0];
                        var title = attrs.dataBsTitle || node.getAttribute('data-bs-title') || '';
                        var bootstrapApi = window.bootstrap;
                        if (!title || !bootstrapApi || !bootstrapApi.Tooltip) return;
                        node.setAttribute('data-bs-title', title);
                        node.setAttribute('data-bs-original-title', title);
                        if (bootstrapApi.Tooltip.getOrCreateInstance) {
                            bootstrapApi.Tooltip.getOrCreateInstance(node, {
                                title: title, trigger: 'hover', placement: 'top', container: 'body', boundary: 'viewport'
                            });
                        } else {
                            new bootstrapApi.Tooltip(node, {
                                title: title, trigger: 'hover', placement: 'top', container: 'body', boundary: 'viewport'
                            });
                        }
                    }, 0, false);
                    scope.$on('$destroy', function () {
                        $timeout.cancel(timer);
                        var bootstrapApi = window.bootstrap;
                        if (bootstrapApi && bootstrapApi.Tooltip) {
                            var instance = bootstrapApi.Tooltip.getInstance(element[0]);
                            if (instance) instance.dispose();
                        }
                    });
                }
            };
        }])
        .controller('UserDashboardController', ['$scope', 'UserDashboardService', function ($scope, UserDashboardService) {
            var vm = this;
            vm.loading = true;
            vm.hasLoaded = false;
            vm.error = '';
            var requestSequence = 0;
            var hoursRequestSequence = 0;
            var mainFilterHours = { days: [] };
            var hoursPeriodSource = 'main';
            vm.hoursLoading = false;
            vm.hoursLoaded = false;
            vm.hoursError = '';
            vm.hoursPeriod = 'all';
            vm.hoursPeriods = [
                { value: 'all', label: 'All' },
                { value: 'week', label: 'This Week' },
                { value: 'today', label: 'Today' }
            ];
            vm.rangeMenuOpen = false;
            vm.customMode = false;
            vm.rangeError = '';
            vm.presets = ['All', 'Today', 'This Week', 'This Month', 'This Quarter', 'This Year', 'Yesterday', 'Previous Week', 'Previous Month', 'Previous Quarter', 'Previous Year', 'Custom Range'];
            vm.selectedPreset = 'Today';
            vm.data = {};

            var dashboardTimeZone = 'Asia/Dubai';
            function dateOnly(date) {
                return new Date(date.getFullYear(), date.getMonth(), date.getDate());
            }
            function globalToday() {
                var parts = new Intl.DateTimeFormat('en-US', {
                    timeZone: dashboardTimeZone,
                    year: 'numeric', month: '2-digit', day: '2-digit'
                }).formatToParts(new Date());
                var values = {};
                parts.forEach(function (part) { values[part.type] = part.value; });
                return new Date(Number(values.year), Number(values.month) - 1, Number(values.day));
            }
            function addDays(date, count) {
                var result = dateOnly(date);
                result.setDate(result.getDate() + count);
                return result;
            }
            function startOfWeek(date) {
                return addDays(date, -date.getDay());
            }
            function startOfHoursWeek(date) {
                return addDays(date, -((date.getDay() + 6) % 7));
            }
            function endOfMonth(date) {
                return new Date(date.getFullYear(), date.getMonth() + 1, 0);
            }
            function startOfQuarter(date) {
                return new Date(date.getFullYear(), Math.floor(date.getMonth() / 3) * 3, 1);
            }
            function endOfQuarter(date) {
                return new Date(date.getFullYear(), Math.floor(date.getMonth() / 3) * 3 + 3, 0);
            }
            function toApiDate(date) {
                var d = dateOnly(date);
                return ('0' + d.getDate()).slice(-2) + '/' + ('0' + (d.getMonth() + 1)).slice(-2) + '/' + d.getFullYear();
            }
            function toDateKey(date) {
                var d = dateOnly(date);
                return d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2);
            }
            function timeToHours(value) {
                var parts = String(value || '00:00').split(':');
                return (parseInt(parts[0], 10) || 0) + ((parseInt(parts[1], 10) || 0) / 60);
            }
            function weeklyReportToHours(report, period, todayKey) {
                var days = report && report.days ? report.days : [];
                if (period === 'today') days = days.filter(function (day) { return day.key === todayKey; });
                return days.map(function (day) {
                    var assignedText = day.totalTime || '00:00';
                    var spentText = day.actualTime || '00:00';
                    var label = period === 'today' ? 'Today' : day.key;
                    if (period !== 'today' && day.key) {
                        var parts = day.key.split('-');
                        label = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2])).toLocaleString('en-US', { weekday: 'short' });
                    }
                    return {
                        day: label,
                        assigned: timeToHours(assignedText),
                        spent: timeToHours(spentText),
                        assignedText: assignedText,
                        spentText: spentText,
                        assignedTooltip: 'Total Time : ' + assignedText + ' hrs',
                        spentTooltip: 'Spent Time : ' + spentText + ' hrs'
                    };
                });
            }
            function hoursPeriodForMainPreset(preset) {
                if (preset === 'Today') return 'today';
                if (preset === 'This Week') return 'week';
                return 'all';
            }
            function setRange(start, end, label, closeMenu) {
                vm.rangeFrom = dateOnly(start);
                vm.rangeTo = dateOnly(end);
                vm.customFromDate = new Date(vm.rangeFrom.getTime());
                vm.customToDate = new Date(vm.rangeTo.getTime());
                vm.rangeDisplay = toApiDate(vm.rangeFrom) + ' - ' + toApiDate(vm.rangeTo);
                vm.selectedPreset = label || '';
                vm.customMode = label === 'Custom Range';
                vm.rangeError = '';
                if (closeMenu) vm.rangeMenuOpen = false;
                vm.load(toApiDate(vm.rangeFrom), toApiDate(vm.rangeTo));
            }

            vm.load = function (fromDate, toDate) {
                var thisRequest = ++requestSequence;
                var thisHoursRequest = ++hoursRequestSequence;
                vm.hoursPeriod = hoursPeriodForMainPreset(vm.selectedPreset);
                hoursPeriodSource = 'main';
                vm.hoursLoading = true;
                vm.hoursError = '';
                vm.loading = true;
                vm.error = '';
                UserDashboardService.getDashboard(fromDate, toDate).then(function (data) {
                    if (thisRequest !== requestSequence) return;
                    var currentHours = vm.data && vm.data.hours;
                    vm.data = data || {};
                    mainFilterHours = vm.data.hours || { days: [] };
                    if (vm.hoursPeriod === 'all' || hoursPeriodSource === 'main') {
                        vm.data.hours = mainFilterHours;
                        vm.hoursLoaded = true;
                    } else if (currentHours) {
                        vm.data.hours = currentHours;
                    }
                    vm.hasLoaded = true;
                }).catch(function () {
                    if (thisRequest === requestSequence) vm.error = 'Unable to load dashboard data. Please try again.';
                }).finally(function () {
                    if (thisRequest !== requestSequence) return;
                    vm.loading = false;
                    if (thisHoursRequest === hoursRequestSequence) vm.hoursLoading = false;
                    $scope.$evalAsync();
                });
            };

            vm.loadTaskHours = function (period) {
                var thisRequest = ++hoursRequestSequence;
                vm.hoursPeriod = period;
                hoursPeriodSource = 'user';
                vm.hoursError = '';
                if (period === 'all') {
                    vm.hoursLoading = false;
                    vm.data = vm.data || {};
                    vm.data.hours = mainFilterHours;
                    vm.hoursLoaded = true;
                    $scope.$evalAsync();
                    return;
                }

                var today = globalToday();
                var weekStart = startOfHoursWeek(today);
                var weekEnd = addDays(weekStart, 6);
                var todayKey = toDateKey(today);
                vm.hoursLoading = true;
                vm.hoursError = '';
                UserDashboardService.getWeeklyReport(toApiDate(weekStart), toApiDate(weekEnd)).then(function (report) {
                    if (thisRequest !== hoursRequestSequence) return;
                    vm.data = vm.data || {};
                    vm.data.hours = { days: weeklyReportToHours(report, period, todayKey) };
                    vm.hoursLoaded = true;
                }).catch(function () {
                    if (thisRequest === hoursRequestSequence) vm.hoursError = 'Unable to update Task Hours.';
                }).finally(function () {
                    if (thisRequest !== hoursRequestSequence) return;
                    vm.hoursLoading = false;
                    $scope.$evalAsync();
                });
            };

            vm.hoursBarHeight = function (value) {
                var hours = Number(value) || 0;
                if (hours <= 0) return '0%';
                return Math.max(2, Math.min(100, hours / 8 * 100)) + '%';
            };

            vm.timeEfficiencyNeedle = function (value) {
                var percent = Math.max(0, Math.min(100, Number(value) || 0));
                return 'rotate(' + ((percent - 50) * 1.8) + 'deg)';
            };

            vm.toggleRangeMenu = function () {
                vm.rangeMenuOpen = !vm.rangeMenuOpen;
                vm.customMode = vm.rangeMenuOpen && vm.selectedPreset === 'Custom Range';
                vm.rangeError = '';
            };

            vm.openCalendar = function (event) {
                var input = event && event.currentTarget;
                if (!input) return;
                try {
                    if (typeof input.showPicker === 'function') {
                        input.showPicker();
                        return;
                    }
                } catch (ignore) { }
                input.focus();
            };

            vm.selectPreset = function (preset) {
                if (preset === 'Custom Range') {
                    vm.selectedPreset = preset;
                    vm.customMode = true;
                    vm.rangeError = '';
                    return;
                }
                var today = globalToday();
                var start = today;
                var end = today;
                var weekStart = startOfWeek(today);
                if (preset === 'All') start = new Date(2020, 0, 1);
                else if (preset === 'This Week') { start = weekStart; end = addDays(weekStart, 6); }
                else if (preset === 'This Month') { start = new Date(today.getFullYear(), today.getMonth(), 1); end = endOfMonth(today); }
                else if (preset === 'This Quarter') { start = startOfQuarter(today); end = endOfQuarter(today); }
                else if (preset === 'This Year') { start = new Date(today.getFullYear(), 0, 1); end = new Date(today.getFullYear(), 11, 31); }
                else if (preset === 'Yesterday') { start = addDays(today, -1); end = start; }
                else if (preset === 'Previous Week') { start = addDays(weekStart, -7); end = addDays(weekStart, -1); }
                else if (preset === 'Previous Month') { start = new Date(today.getFullYear(), today.getMonth() - 1, 1); end = new Date(today.getFullYear(), today.getMonth(), 0); }
                else if (preset === 'Previous Quarter') { start = new Date(startOfQuarter(today).getFullYear(), startOfQuarter(today).getMonth() - 3, 1); end = addDays(startOfQuarter(today), -1); }
                else if (preset === 'Previous Year') { start = new Date(today.getFullYear() - 1, 0, 1); end = new Date(today.getFullYear() - 1, 11, 31); }
                setRange(start, end, preset, true);
            };

            vm.applyCustomRange = function () {
                if (!(vm.customFromDate instanceof Date) || isNaN(vm.customFromDate.getTime()) || !(vm.customToDate instanceof Date) || isNaN(vm.customToDate.getTime())) {
                    vm.rangeError = 'Select both From Date and To Date.';
                    return;
                }
                if (dateOnly(vm.customToDate) < dateOnly(vm.customFromDate)) {
                    vm.rangeError = 'To Date must be on or after From Date.';
                    return;
                }
                setRange(vm.customFromDate, vm.customToDate, 'Custom Range', true);
            };

            var today = globalToday();
            setRange(today, today, 'Today', false);
        }]);
}());
